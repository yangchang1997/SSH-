package org.java.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.java.pojo.User;
import org.java.service.Userservice;
import org.springframework.beans.factory.annotation.Autowired;

import com.opensymphony.xwork2.Action;

public class UserAction implements Action {
	private int ddid;

	public int getDdid() {
		return ddid;
	}

	public void setDdid(int ddid) {
		this.ddid = ddid;
	}
@Autowired 
private Userservice userservice;
	@Override
	public String execute() throws Exception {
		List<User> users=userservice.users();
		System.out.println(users);
		ServletActionContext.getRequest().getSession().setAttribute("user",users);
		return "show";
		
	}

	public String deleteUser() {
		userservice.deleteUser(ddid);
		System.out.println(ddid);
		return "show";

	}
}
