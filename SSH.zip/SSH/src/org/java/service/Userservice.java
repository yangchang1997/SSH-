package org.java.service;

import java.util.List;

import org.java.pojo.User;

public interface Userservice {
	List<User> users();
	void deleteUser(int id);
}
