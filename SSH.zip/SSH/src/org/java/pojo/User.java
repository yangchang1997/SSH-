package org.java.pojo;

import java.io.Serializable;

public class User implements Serializable {
private int userid;
private String name;
public int getUserid() {
	return userid;
}
public void setUserid(int userid) {
	this.userid = userid;
}
private String message;

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@Override
public String toString() {
	return "User [userid=" + userid + ", name=" + name + ", message=" + message + "]";
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
}
