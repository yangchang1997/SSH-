package org.java.dao;

import java.util.List;

import org.java.pojo.User;

public interface Userdao {
List<User> users();
void deleteUser(int id);
}
