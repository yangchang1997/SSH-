package org.java.daoimpl;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.java.dao.Userdao;
import org.java.pojo.User;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Repository
public class Userdaoimpl implements Userdao{
	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;
	Session session=sessionFactory.openSession();
	@Override
	public List<User> users() {
		 List<User> users=sessionFactory.getCurrentSession().createQuery("from User").list();
			return users;
	}

	@Override
	public void deleteUser(int id) {
		User user=(User) session.get(User.class, id);
		session.delete(user);
		List<User> users=sessionFactory.getCurrentSession().createQuery("from User").list();
		session.flush();
		
	}

}
